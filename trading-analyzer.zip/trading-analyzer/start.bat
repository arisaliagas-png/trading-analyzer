@echo off
title AI Trading Analyzer
echo Starting AI Trading Analyzer Backend & Frontend...
cd /d "%~dp0"
npm run start
pause
